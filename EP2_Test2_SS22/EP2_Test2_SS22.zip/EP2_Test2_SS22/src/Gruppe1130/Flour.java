package Gruppe1130;

import java.util.Objects;

// Flour as ingredient.
//
public class Flour {

    // TODO: Implementation of this class and all necessary methods.

    // Returns the name of the ingredient.
    public String toString() {
        return "";
    }

}


