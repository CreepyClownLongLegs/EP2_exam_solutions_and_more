package Gruppe1130;

import java.util.Objects;

// Milk as ingredient.
//
public class Milk {

    // TODO: Implementation of this class and all necessary methods.

    // Returns the name of the ingredient.
    public String toString() {
        return "";
    }
}
