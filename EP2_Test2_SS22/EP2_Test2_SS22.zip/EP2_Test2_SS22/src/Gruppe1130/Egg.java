package Gruppe1130;

import java.util.Objects;

// An egg as an ingredient.
//
public class Egg {

    // TODO: Implementation of this class and all necessary methods.

    // Returns the name of the ingredient.
    public String toString() {
        return "";
    }

}
