package Gruppe1130;

// Represents a scale (=Waage).
//
public interface Scale {

    // Returns the weight in grams.
    int getGrams();
}
