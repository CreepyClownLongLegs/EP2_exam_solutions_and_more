package Gruppe1300;

// Milk as ingredient.
//
public class Milk {
    // TODO: Implementation of this class and all necessary methods.
}
