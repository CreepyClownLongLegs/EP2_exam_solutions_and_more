package Gruppe1300;

// An egg as an ingredient.
//
public class Egg {
    // TODO: Implementation of this class and all necessary methods.
}
