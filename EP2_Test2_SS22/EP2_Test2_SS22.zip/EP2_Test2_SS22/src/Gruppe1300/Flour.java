package Gruppe1300;

// Flour as ingredient.
//
public class Flour {
    // TODO: Implementation of this class and all necessary methods.
}
