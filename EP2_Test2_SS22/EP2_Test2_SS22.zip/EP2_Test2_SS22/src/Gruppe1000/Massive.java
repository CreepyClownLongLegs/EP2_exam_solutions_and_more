package Gruppe1000;

// Represents a mass. Please, do not change this
// interface definition!
//
public interface Massive {

    // Returns the total mass of 'this'.
    double getMass();
}